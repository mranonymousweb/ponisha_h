<?php
// تنظیم هدرهای CORS برای اجازه درخواست‌ها از دامنه‌های مختلف
header('Access-Control-Allow-Origin: https://adobeiran.ir');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Origin, Referer');
header('Access-Control-Allow-Credentials: true');

// اگر درخواست از نوع OPTIONS است، بدون پردازش بیشتر پاسخ دهید و تمام کنید
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// بررسی هدر Referer برای جلوگیری از دسترسی غیرمجاز
$allowed_referer = 'https://adobeiran.ir'; // دامنه مجاز
if (!isset($_SERVER['HTTP_REFERER']) || strpos($_SERVER['HTTP_REFERER'], $allowed_referer) === false) {
    header('HTTP/1.0 403 Forbidden');
    echo 'Access Denied: Invalid Referer.';
    exit;
}

// بررسی هدر User-Agent برای شناسایی دانلود منیجرها
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$blocked_agents = [
    'FDMan', 'wget', 'curl', 'libwww-perl', 
    'DownloadManager', 'WinHTTP', 'Thunder', 
    'Indy Library'
];

// بررسی اینکه آیا درخواست از سمت دانلود منیجر است
foreach ($blocked_agents as $blocked_agent) {
    if (strpos($user_agent, $blocked_agent) !== false) {
        header('HTTP/1.0 403 Forbidden');
        echo 'Access Denied: Download managers are not allowed.';
        exit;
    }
}

// مسیر اصلی برای فایل‌ها
$base_path = realpath(__DIR__ . '/files/') . '/';

// بررسی پارامتر 'file' که نشان‌دهنده مسیر فایل است
if (!isset($_GET['file']) || empty($_GET['file'])) {
    header('HTTP/1.0 400 Bad Request');
    echo 'Invalid request: file parameter is missing.';
    exit;
}

// دریافت نام فایل و مسیر کامل آن
$file = basename($_GET['file']); // نام فایل
$file_path = $base_path . $_GET['file']; // مسیر کامل فایل

// بررسی اینکه فایل وجود دارد یا نه
if (!file_exists($file_path)) {
    header('HTTP/1.0 404 Not Found');
    echo "Error: File does not exist.\n";
    exit;
}



// ارسال هدرها برای پخش ویدیو به جای دانلود
header('Content-Type: ' . $content_type);
header('Content-Length: ' . filesize($file_path));
header('Content-Disposition: inline; filename="' . $file . '"');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
header('Accept-Ranges: bytes'); // پشتیبانی از پخش جزئی فایل
header('Content-Transfer-Encoding: binary'); // جلوگیری از تبدیل فایل
header('X-Content-Type-Options: nosniff'); // جلوگیری از شناسایی نوع فایل توسط مرورگر

// خواندن و ارسال محتوای فایل به صورت Stream
$fp = fopen($file_path, 'rb');
if ($fp === false) {
    header('HTTP/1.0 500 Internal Server Error');
    echo "Error: Unable to open the file.\n";
    exit;
}

while (!feof($fp)) {
    echo fread($fp, 8192); // ارسال داده‌ها به صورت پیوسته
    flush(); // ارسال داده‌ها به مرورگر
}

fclose($fp);
exit;
?>
